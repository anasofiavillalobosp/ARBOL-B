# Proyecto Árbol B - Adaptación a Python

Adaptación del proyecto Java original, conservando la separación MVC (modelo, vista y controlador).

## Requisitos
- Python 3.10 o superior (no requiere instalar paquetes externos).

## Ejecución
Desde la carpeta `ProyectoArbolB_Python`, ejecutar:

```bash
python main.py
```

El programa inicia con `D = 2`, igual que el `AplMain.java` original. Para cambiar el grado mínimo, modificar el argumento en `main.py`.

## Estructura
- `modelo/nodo_b.py`: representa cada página/nodo del árbol.
- `modelo/arbol_b.py`: implementa inserción, búsqueda, eliminación, divisiones, redistribución, fusión y consultas.
- `vista/vista_arbol_b.py`: menú y mensajes de consola.
- `controlador/controlador_arbol_b.py`: conecta la vista con el modelo.
- `main.py`: punto de entrada.

## Operaciones
1. Insertar clave (las claves duplicadas no se insertan).
2. Buscar clave.
3. Eliminar clave.
4. Consultar mínimo.
5. Consultar máximo.
6. Buscar rango inclusivo.
7. Recorrer en orden.
8. Mostrar árbol por niveles.
9. Consultar altura (árbol vacío: 0; raíz sola: 1).
10. Consultar si está vacío.
11. Limpiar árbol.

La división de páginas y la reestructuración (redistribución/fusión al eliminar) se realizan automáticamente como parte de las operaciones de inserción y eliminación; no son una opción independiente del menú Java.

## Nota de adaptación
Se conservaron los nombres conceptuales y el comportamiento del programa Java. Python utiliza listas dinámicas para las claves e hijos en lugar de arreglos de tamaño fijo, pero mantiene las reglas del árbol B y el grado mínimo `D`.
