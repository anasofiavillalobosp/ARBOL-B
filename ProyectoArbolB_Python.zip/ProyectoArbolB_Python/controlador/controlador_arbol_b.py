from modelo.arbol_b import ArbolB
from vista.vista_arbol_b import VistaArbolB


class ControladorArbolB:
    """Coordina la vista y el modelo."""

    def __init__(self, D):
        self.arbol = ArbolB(D)
        self.vista = VistaArbolB()

    def iniciar(self):
        while True:
            opcion = self.vista.mostrar_menu()
            if opcion == 1:
                self.insertar()
            elif opcion == 2:
                self.buscar()
            elif opcion == 3:
                self.eliminar()
            elif opcion == 4:
                self.vista.mostrar_extremo(self.arbol.obtener_minimo(), "Mínimo")
            elif opcion == 5:
                self.vista.mostrar_extremo(self.arbol.obtener_maximo(), "Máximo")
            elif opcion == 6:
                self.buscar_rango()
            elif opcion == 7:
                self.vista.mostrar_mensaje("Recorrido en orden:")
                self.vista.mostrar_claves(self.arbol.recorrer_en_orden())
            elif opcion == 8:
                self.vista.mostrar_arbol(self.arbol.imprimir_por_niveles())
            elif opcion == 9:
                self.vista.mostrar_altura(self.arbol.altura())
            elif opcion == 10:
                mensaje = ("El árbol está vacío." if self.arbol.esta_vacio()
                           else "El árbol contiene claves.")
                self.vista.mostrar_mensaje(mensaje)
            elif opcion == 11:
                self.arbol.limpiar()
                self.vista.mostrar_mensaje("El árbol se ha limpiado correctamente.")
            elif opcion == 0:
                self.vista.mostrar_mensaje("Programa finalizado.")
                break
            else:
                self.vista.mostrar_mensaje("Opción no válida.")

    def insertar(self):
        clave = self.vista.leer_entero("Ingrese la clave que desea insertar: ")
        if self.arbol.insertar(clave):
            self.vista.mostrar_mensaje("Clave insertada correctamente.")
        else:
            self.vista.mostrar_mensaje("La clave ya existe en el árbol.")

    def buscar(self):
        clave = self.vista.leer_entero("Ingrese la clave que desea buscar: ")
        self.vista.mostrar_resultado_busqueda(self.arbol.buscar(clave), clave)

    def eliminar(self):
        clave = self.vista.leer_entero("Ingrese la clave que desea eliminar: ")
        if self.arbol.eliminar(clave):
            self.vista.mostrar_mensaje("Clave eliminada correctamente.")
        else:
            self.vista.mostrar_mensaje("La clave no existe en el árbol.")

    def buscar_rango(self):
        minimo = self.vista.leer_entero("Ingrese el límite inferior: ")
        maximo = self.vista.leer_entero("Ingrese el límite superior: ")
        if minimo > maximo:
            self.vista.mostrar_mensaje(
                "El límite inferior no puede ser mayor que el superior."
            )
            return
        self.vista.mostrar_mensaje("Claves encontradas en el rango:")
        self.vista.mostrar_claves(self.arbol.buscar_rango(minimo, maximo))
