from controlador.controlador_arbol_b import ControladorArbolB


if __name__ == "__main__":
    # El proyecto Java inicia con D = 2; se conserva ese valor.
    controlador = ControladorArbolB(2)
    controlador.iniciar()
