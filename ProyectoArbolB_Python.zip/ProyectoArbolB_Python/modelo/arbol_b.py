from collections import deque
from .nodo_b import NodoB


class Division:
    """Guarda la clave que sube al padre y el nuevo nodo derecho."""
    def __init__(self, clave_promovida, nuevo_derecho):
        self.clave_promovida = clave_promovida
        self.nuevo_derecho = nuevo_derecho


class ArbolB:
    """
    Árbol B con grado mínimo D.
    Cada nodo (excepto la raíz) mantiene entre D y 2D claves.
    La raíz puede tener menos claves.
    """

    def __init__(self, D: int):
        if D < 1:
            raise ValueError("D debe ser mayor o igual a 1.")
        self.D = D
        self.raiz = NodoB(D, True)

    def get_D(self):
        return self.D

    def esta_vacio(self):
        return self.raiz.cantidad_claves == 0

    def limpiar(self):
        self.raiz = NodoB(self.D, True)

    def buscar(self, clave: int) -> bool:
        return self._buscar_en_nodo(self.raiz, clave)

    def contiene(self, clave: int) -> bool:
        return self.buscar(clave)

    def _buscar_en_nodo(self, nodo, clave):
        i = 0
        while i < nodo.cantidad_claves and clave > nodo.claves[i]:
            i += 1
        if i < nodo.cantidad_claves and clave == nodo.claves[i]:
            return True
        if nodo.es_hoja:
            return False
        return self._buscar_en_nodo(nodo.hijos[i], clave)

    def insertar(self, clave: int) -> bool:
        if self.buscar(clave):
            return False
        division = self._insertar(self.raiz, clave)
        if division is not None:
            nueva_raiz = NodoB(self.D, False)
            nueva_raiz.claves = [division.clave_promovida]
            nueva_raiz.hijos = [self.raiz, division.nuevo_derecho]
            nueva_raiz.actualizar_cantidad()
            self.raiz = nueva_raiz
        return True

    def _insertar(self, nodo, clave):
        if nodo.es_hoja:
            i = nodo.cantidad_claves - 1
            while i >= 0 and clave < nodo.claves[i]:
                i -= 1
            nodo.claves.insert(i + 1, clave)
            nodo.actualizar_cantidad()
        else:
            i = 0
            while i < nodo.cantidad_claves and clave > nodo.claves[i]:
                i += 1
            division_hijo = self._insertar(nodo.hijos[i], clave)
            if division_hijo is not None:
                nodo.claves.insert(i, division_hijo.clave_promovida)
                nodo.hijos.insert(i + 1, division_hijo.nuevo_derecho)
                nodo.actualizar_cantidad()

        if nodo.cantidad_claves > 2 * self.D:
            return self._dividir_nodo(nodo)
        return None

    def _dividir_nodo(self, nodo):
        d = self.D
        clave_promovida = nodo.claves[d]
        derecho = NodoB(d, nodo.es_hoja)
        derecho.claves = nodo.claves[d + 1:]
        derecho.actualizar_cantidad()
        if not nodo.es_hoja:
            derecho.hijos = nodo.hijos[d + 1:]
            nodo.hijos = nodo.hijos[:d + 1]
        nodo.claves = nodo.claves[:d]
        nodo.actualizar_cantidad()
        return Division(clave_promovida, derecho)

    def obtener_minimo(self):
        if self.esta_vacio():
            return None
        actual = self.raiz
        while not actual.es_hoja:
            actual = actual.hijos[0]
        return actual.claves[0]

    def obtener_maximo(self):
        if self.esta_vacio():
            return None
        actual = self.raiz
        while not actual.es_hoja:
            actual = actual.hijos[actual.cantidad_claves]
        return actual.claves[actual.cantidad_claves - 1]

    def recorrer_en_orden(self):
        resultado = []
        self._recorrer_en_orden_recursivo(self.raiz, resultado)
        return resultado

    def _recorrer_en_orden_recursivo(self, nodo, resultado):
        for i in range(nodo.cantidad_claves):
            if not nodo.es_hoja:
                self._recorrer_en_orden_recursivo(nodo.hijos[i], resultado)
            resultado.append(nodo.claves[i])
        if not nodo.es_hoja:
            self._recorrer_en_orden_recursivo(
                nodo.hijos[nodo.cantidad_claves], resultado
            )

    def buscar_rango(self, minimo, maximo):
        if minimo > maximo:
            return []
        return [c for c in self.recorrer_en_orden() if minimo <= c <= maximo]

    def altura(self):
        if self.esta_vacio():
            return 0
        niveles = 0
        actual = self.raiz
        while actual is not None:
            niveles += 1
            if actual.es_hoja:
                break
            actual = actual.hijos[0]
        return niveles

    def imprimir_por_niveles(self):
        if self.esta_vacio():
            return "El árbol está vacío."
        lineas = []
        cola = deque([(self.raiz, 0)])
        nivel_actual = 0
        partes = []
        while cola:
            nodo, nivel = cola.popleft()
            if nivel != nivel_actual:
                lineas.append(f"Nivel {nivel_actual}: " + " ".join(partes))
                partes = []
                nivel_actual = nivel
            partes.append("[" + " | ".join(map(str, nodo.claves)) + "]")
            if not nodo.es_hoja:
                for hijo in nodo.hijos:
                    cola.append((hijo, nivel + 1))
        lineas.append(f"Nivel {nivel_actual}: " + " ".join(partes))
        return "\n".join(lineas)

    def eliminar(self, clave: int) -> bool:
        if not self.buscar(clave):
            return False
        self._eliminar_recursivo(self.raiz, clave)
        if self.raiz.cantidad_claves == 0:
            if self.raiz.es_hoja:
                self.raiz = NodoB(self.D, True)
            else:
                self.raiz = self.raiz.hijos[0]
        return True

    def _eliminar_recursivo(self, nodo, clave):
        i = 0
        while i < nodo.cantidad_claves and clave > nodo.claves[i]:
            i += 1

        if i < nodo.cantidad_claves and nodo.claves[i] == clave:
            if nodo.es_hoja:
                self._eliminar_de_hoja(nodo, i)
            else:
                predecesor = self._obtener_predecesor(nodo.hijos[i])
                nodo.claves[i] = predecesor
                self._eliminar_recursivo(nodo.hijos[i], predecesor)
                self._reparar_hijo(nodo, i)
        elif not nodo.es_hoja:
            self._eliminar_recursivo(nodo.hijos[i], clave)
            self._reparar_hijo(nodo, i)
        nodo.actualizar_cantidad()

    def _eliminar_de_hoja(self, nodo, posicion):
        nodo.claves.pop(posicion)
        nodo.actualizar_cantidad()

    def _obtener_predecesor(self, nodo):
        while not nodo.es_hoja:
            nodo = nodo.hijos[nodo.cantidad_claves]
        return nodo.claves[nodo.cantidad_claves - 1]

    def _reparar_hijo(self, padre, posicion):
        hijo = padre.hijos[posicion]
        if hijo.cantidad_claves >= self.D:
            return
        if posicion > 0 and padre.hijos[posicion - 1].cantidad_claves > self.D:
            self._redistribuir_desde_izquierda(padre, posicion)
        elif (posicion < padre.cantidad_claves
              and padre.hijos[posicion + 1].cantidad_claves > self.D):
            self._redistribuir_desde_derecha(padre, posicion)
        else:
            if posicion > 0:
                self._fusionar(padre, posicion - 1)
            else:
                self._fusionar(padre, posicion)

    def _redistribuir_desde_izquierda(self, padre, posicion):
        hijo = padre.hijos[posicion]
        hermano = padre.hijos[posicion - 1]
        hijo.claves.insert(0, padre.claves[posicion - 1])
        padre.claves[posicion - 1] = hermano.claves.pop()
        if not hijo.es_hoja:
            hijo.hijos.insert(0, hermano.hijos.pop())
        hijo.actualizar_cantidad()
        hermano.actualizar_cantidad()

    def _redistribuir_desde_derecha(self, padre, posicion):
        hijo = padre.hijos[posicion]
        hermano = padre.hijos[posicion + 1]
        hijo.claves.append(padre.claves[posicion])
        padre.claves[posicion] = hermano.claves.pop(0)
        if not hijo.es_hoja:
            hijo.hijos.append(hermano.hijos.pop(0))
        hijo.actualizar_cantidad()
        hermano.actualizar_cantidad()

    def _fusionar(self, padre, posicion):
        izquierdo = padre.hijos[posicion]
        derecho = padre.hijos[posicion + 1]
        izquierdo.claves.append(padre.claves.pop(posicion))
        izquierdo.claves.extend(derecho.claves)
        if not izquierdo.es_hoja:
            izquierdo.hijos.extend(derecho.hijos)
        padre.hijos.pop(posicion + 1)
        izquierdo.actualizar_cantidad()
        padre.actualizar_cantidad()
