class NodoB:
    """Representa una página de un árbol B de grado mínimo D."""

    def __init__(self, D: int, es_hoja: bool):
        self.claves = []
        self.hijos = []
        self.cantidad_claves = 0
        self.es_hoja = es_hoja

    def actualizar_cantidad(self):
        self.cantidad_claves = len(self.claves)

    def get_cantidad_claves(self):
        return self.cantidad_claves

    def es_hoja_nodo(self):
        return self.es_hoja
