class VistaArbolB:
    """Maneja la interacción por consola; no contiene la lógica del árbol."""

    def mostrar_menu(self):
        print("\n========== ÁRBOL B ==========")
        print("1. Insertar clave")
        print("2. Buscar clave")
        print("3. Eliminar clave")
        print("4. Consultar mínimo")
        print("5. Consultar máximo")
        print("6. Buscar rango")
        print("7. Recorrer en orden")
        print("8. Mostrar árbol por niveles")
        print("9. Consultar altura")
        print("10. Consultar si está vacío")
        print("11. Limpiar árbol")
        print("0. Salir")
        print("=============================")
        return self.leer_entero("Seleccione una opción: ")

    def leer_entero(self, mensaje):
        while True:
            try:
                return int(input(mensaje))
            except ValueError:
                print("Error: debe ingresar un número entero.")

    def mostrar_mensaje(self, mensaje):
        print(mensaje)

    def mostrar_resultado_busqueda(self, encontrada, clave):
        if encontrada:
            print(f"La clave {clave} existe en el árbol.")
        else:
            print(f"La clave {clave} no existe en el árbol.")

    def mostrar_claves(self, claves):
        if not claves:
            print("No hay claves para mostrar.")
        else:
            print(claves)

    def mostrar_extremo(self, valor, tipo):
        if valor is None:
            print(f"El árbol está vacío. No hay {tipo.lower()}.")
        else:
            print(f"{tipo} del árbol: {valor}")

    def mostrar_arbol(self, arbol):
        print(arbol)

    def mostrar_altura(self, altura):
        print(f"Altura del árbol: {altura}")
