package controlador;

public class AplMain {

	public static void main(String[] args) {
        ControladorArbolB controlador = new ControladorArbolB(2);
        controlador.iniciar();
    }
}
