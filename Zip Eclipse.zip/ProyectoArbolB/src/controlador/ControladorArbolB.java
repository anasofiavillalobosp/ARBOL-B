package controlador;

import java.util.List;

import modelo.ArbolB;
import vista.VistaArbolB;

/**
 * Controlador del arbol B.
 *
 * Coordina la comunicacion entre el modelo y la vista.
 * Recibe las opciones del usuario y solicita al modeloque ejecute las operaciones correspondientes.
 */
public class ControladorArbolB {
    // Modelo que contiene la estructura del arbol B.
    private ArbolB arbol;
    // Vista encargada de la interaccion con el usuario.
    private VistaArbolB vista;
    /**
     * Constructor del controlador.
     * @param D cantidad minima de claves del arbol.
     */
    public ControladorArbolB(int D) {
        // Se crea el modelo con el orden indicado.
        arbol = new ArbolB(D);
        // Se crea la vista.
        vista = new VistaArbolB();
    }

    /**
     * Inicia la ejecucion del programa.
     * Mantiene el menu activo hasta que el usuario seleccione la opcion de salir.
     */
    public void iniciar() {
        int opcion;
        do {
            opcion = vista.mostrarMenu();
            switch (opcion) {
                case 1:
                    insertar();
                    break;

                case 2:
                    buscar();
                    break;

                case 3:
                    eliminar();
                    break;

                case 4:
                    consultarMinimo();
                    break;

                case 5:
                    consultarMaximo();
                    break;

                case 6:
                    buscarRango();
                    break;

                case 7:
                    recorrerEnOrden();
                    break;

                case 8:
                    mostrarPorNiveles();
                    break;

                case 9:
                    mostrarAltura();
                    break;

                case 10:
                    consultarVacio();
                    break;

                case 11:
                    limpiar();
                    break;

                case 0:
                    vista.mostrarMensaje("Programa finalizado.");
                    break;

                default:
                    vista.mostrarMensaje("Opcion no valida.");
                    break;
            }

        } while (opcion != 0);
    }

    // Solicita una clave y la inserta en el arbol.
    private void insertar() {
        int clave = vista.leerEntero("Ingrese la clave que desea insertar: ");
        // El modelo se encarga de insertar y reorganizar el arbol.
        boolean insertada = arbol.insertar(clave);
        if (insertada) {
            vista.mostrarMensaje("Clave insertada correctamente.");
        } else {
            vista.mostrarMensaje("La clave ya existe en el arbol.");
        }
    }

    // Consulta si una clave se encuentra en el arbol.
    private void buscar() {
        int clave = vista.leerEntero("Ingrese la clave que desea buscar: ");
        boolean encontrada = arbol.buscar(clave);
        vista.mostrarResultadoBusqueda(encontrada, clave);
    }

    // Elimina una clave del arbol.
    private void eliminar() {
        int clave = vista.leerEntero("Ingrese la clave que desea eliminar: ");
        boolean eliminada = arbol.eliminar(clave);
        if (eliminada) {
            vista.mostrarMensaje("Clave eliminada correctamente.");
        } else {
            vista.mostrarMensaje("La clave no existe en el arbol.");
        }
    }

    // Consulta la clave menor del arbol.
    private void consultarMinimo() {
        Integer minimo = arbol.obtenerMinimo();
        vista.mostrarExtremo(minimo, "Minimo");
    }

    //Consulta la clave mayor del arbol.
    private void consultarMaximo() {
        Integer maximo = arbol.obtenerMaximo();
        vista.mostrarExtremo(maximo, "Maximo");
    }

    // Busca las claves comprendidas entre dos valores.
    private void buscarRango() {
        int minimo = vista.leerEntero("Ingrese el limite inferior: ");
        int maximo = vista.leerEntero("Ingrese el limite superior: ");
        if (minimo > maximo) {
            vista.mostrarMensaje("El limite inferior no puede ser mayor que el superior.");
            return;
        }
        List<Integer> resultado = arbol.buscarRango(minimo, maximo);

        vista.mostrarMensaje("Claves encontradas en el rango:");
        vista.mostrarClaves(resultado);
    }

    // Ejecuta el recorrido En Orden del arbol.
    private void recorrerEnOrden() {
        List<Integer> claves = arbol.recorrerEnOrden();

        vista.mostrarMensaje("Recorrido En Orden:");
        vista.mostrarClaves(claves);
    }

    // Muestra la estructura del arbol por niveles.
    private void mostrarPorNiveles() {
        String resultado = arbol.imprimirPorNiveles();
        vista.mostrarArbol(resultado);
    }

    // Consulta la altura del arbol.
    private void mostrarAltura() {
        int altura = arbol.altura();
        vista.mostrarAltura(altura);
    }

    // Consulta si el arbol esta vacio.
    private void consultarVacio() {
        if (arbol.estaVacio()) {
            vista.mostrarMensaje("El arbol esta vacio.");
        } else {
            vista.mostrarMensaje("El arbol contiene claves.");
        }
    }

    // Elimina todas las claves del arbol.
    private void limpiar() {
        arbol.limpiar();
        vista.mostrarMensaje("El arbol se ha limpiado correctamente.");
    }
}
