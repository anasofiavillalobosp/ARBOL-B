package modelo;

import java.util.ArrayList;
import java.util.List;

/**
 * Implementacion de un arbol B de orden D por (Cairó & Guardati, 2006).
 *
 * D representa la cantidad minima de claves que deben almacenar las paginas, excepto la raiz.
 */
public class ArbolB {
    // Cantidad minima de claves por pagina.
    private int D;
    // Referencia al nodo principal(LA RAIZ o ROOT) del arbol.
    private NodoB raiz;

    /**
     * Constructor del arbol B.
     *
     * @param D cantidad minima de claves.
     */
    public ArbolB(int D) {

        if (D < 1) {
            throw new IllegalArgumentException("D debe ser mayor o igual a 1.");
        }

        this.D = D;

        // Inicialmente el arbol tiene una raiz vacia que tambien es una hoja.
        raiz = new NodoB(D, true);
    }

    // ------1. OPERACIONES DE INICIALIZACION-------

    // Comprueba si el arbol esta vacio.
    public boolean estaVacio() {
        return raiz.cantidadClaves == 0;
    }

    //Elimina todos los elementos del arbol.
    public void limpiar() {
        raiz = new NodoB(D, true);
    }

    // Devuelve el orden D del arbol.
    public int getD() {
        return D;
    }

    // ---------2. BUSQUEDA---------

    /**
     * Busca una clave dentro del arbol.
     *
     * @param clave elemento que se desea encontrar.
     * @return true si existe, false en caso contrario.
     */
    public boolean buscar(int clave) {

        return buscarEnNodo(raiz, clave);
    }

    //Realiza la busqueda.
    private boolean buscarEnNodo(NodoB nodo, int clave) {

        int i = 0;
        // Busca la primera posicion cuya clave sea mayor o igual al elemento buscado.
        while (i < nodo.cantidadClaves && clave > nodo.claves[i]) {
            i++;
        }

        // Si encuentra la clave, termina la busqueda.
        if (i < nodo.cantidadClaves && clave == nodo.claves[i]) {
            return true;
        }

        // Si es hoja y no encontro la clave, el elemento no pertenece al arbol.
        if (nodo.esHoja) {
            return false;
        }

        // Continua la busqueda por el hijo correspondiente.
        return buscarEnNodo(nodo.hijos[i], clave);
    }

    // Comprueba si una clave pertenece al arbol.
    public boolean contiene(int clave) {
        return buscar(clave);
    }

    // ----------3. INSERCION----------

    /**
     * Inserta una nueva clave en el arbol.
     *
     * @param clave elemento que se desea insertar.
     * @return true si se inserto, false si ya existia.
     */
    public boolean insertar(int clave) {
        // No se permiten claves duplicadas.
        if (buscar(clave)) {
            return false;
        }

        // Se inicia la insercion desde la raiz.
        Division division = insertar(raiz, clave);

        // Si la raiz se dividio, se crea una nueva raiz.
        if (division != null) {
            NodoB nuevaRaiz = new NodoB(D, false);

            // La clave central pasa a ser la raiz.
            nuevaRaiz.claves[0] = division.clavePromovida;
            nuevaRaiz.cantidadClaves = 1;

            // Se conectan los dos nodos resultantes.
            nuevaRaiz.hijos[0] = raiz;
            nuevaRaiz.hijos[1] = division.nuevoDerecho;

            raiz = nuevaRaiz;
        }

        return true;
    }

    /**
     * Realiza la insercion.
     *
     * Si un nodo supera 2D claves, devuelve la informacion necesaria para dividirlo.
     */
    private Division insertar(
            NodoB nodo, int clave) {

        if (nodo.esHoja) {

            // Encuentra la posicion donde debe insertarse la nueva clave para conservar el orden.
            int i = nodo.cantidadClaves - 1;

            while (i >= 0 && clave < nodo.claves[i]) {
                nodo.claves[i + 1] = nodo.claves[i];
                i--;
            }

            nodo.claves[i + 1] = clave;
            nodo.cantidadClaves++;

        } else {
            // Determina el hijo por el cual debe continuar.
            int i = 0;

            while (i < nodo.cantidadClaves && clave > nodo.claves[i]) {
                i++;
            }

            // Continua la insercion en el hijo seleccionado.
            Division divisionHijo = insertar(nodo.hijos[i], clave);

            // Si el hijo se dividio, su clave central debe incorporarse al nodo actual.
            if (divisionHijo != null) {

                // Desplaza las claves hacia la derecha.
                for (int j = nodo.cantidadClaves; j > i; j--) {
                    nodo.claves[j] = nodo.claves[j - 1];
                }

                // Desplaza las referencias a los hijos.
                for (int j = nodo.cantidadClaves + 1; j > i + 1; j--) {
                    nodo.hijos[j] = nodo.hijos[j - 1];
                }

                // Incorpora la clave que subio del hijo.
                nodo.claves[i] = divisionHijo.clavePromovida;

                // Conecta el nuevo hijo derecho.
                nodo.hijos[i + 1] = divisionHijo.nuevoDerecho;

                nodo.cantidadClaves++;
            }
        }

        // Si el nodo tiene mas de 2D claves,  es necesario realizar una division.
        if (nodo.cantidadClaves > 2 * D) {
            return dividirNodo(nodo);
        }

        return null;
    }

    // 4. DIVISION DE NODOS (SPLIT)

    /**
     * Divide un nodo que tiene 2D + 1 claves.
     *
     * La clave ubicada en la posicion D sube al padre y los nodos izquierdo y derecho quedan con D claves.
     */
    private Division dividirNodo(NodoB nodo) {
        // Se crea el nuevo nodo derecho.
        NodoB derecho = new NodoB(D, nodo.esHoja);

        // La clave central sera promovida al padre.
        int clavePromovida = nodo.claves[D];

        // Se copian las claves posteriores a la central.
        for (int i = 0; i < D; i++) {
            derecho.claves[i] = nodo.claves[D + 1 + i];
        }

        derecho.cantidadClaves = D;

        // Si el nodo no es hoja, tambien se distribuyen sus referencias a los hijos.
        if (!nodo.esHoja) {

            for (int i = 0; i <= D; i++) {
                derecho.hijos[i] = nodo.hijos[D + 1 + i];
                // Se limpian las referencias que ya pertenecen al nuevo nodo derecho.
                nodo.hijos[D + 1 + i] = null;
            }
        }

        // El nodo original conserva las D claves izquierdas.
        nodo.cantidadClaves = D;

        // Se devuelve la clave promovida y el nuevo nodo.
        return new Division(clavePromovida, derecho);
    }

    /**
     * Almacena temporalmente el resultado de una division.
     */
    private static class Division {
        int clavePromovida;
        NodoB nuevoDerecho;

        Division(int clavePromovida, NodoB nuevoDerecho) {
            this.clavePromovida = clavePromovida;
            this.nuevoDerecho = nuevoDerecho;
        }
    }

    // ----------5. CONSULTAR MINIMO Y MAXIMO-------------

    // Obtiene la menor clave del arbol.
    public Integer obtenerMinimo() {
        if (estaVacio()) {
            return null;
        }

        NodoB actual = raiz;

        // El minimo se encuentra en el primer hijo de cada pagina hasta llegar a una hoja.
        while (!actual.esHoja) {
            actual = actual.hijos[0];
        }

        return actual.claves[0];
    }

     //Obtiene la mayor clave del arbol.
    public Integer obtenerMaximo() {
        if (estaVacio()) {
            return null;
        }

        NodoB actual = raiz;

        // El maximo se encuentra en el ultimo hijo de cada pagina hasta llegar a una hoja.
        while (!actual.esHoja) {
            actual = actual.hijos[actual.cantidadClaves];
        }

        return actual.claves[actual.cantidadClaves - 1];
    }

    // -------6. RECORRIDO EN ORDEN----------

     // Devuelve todas las claves ordenadas de menor a mayor.
    public List<Integer> recorrerEnOrden() {

        List<Integer> resultado = new ArrayList<>();
        recorrerEnOrdenRecursivo(raiz, resultado);

        return resultado;
    }

    /**
     * Realiza el recorrido en orden del arbol B.
     */
    private void recorrerEnOrdenRecursivo(
            NodoB nodo, List<Integer> resultado) {

        for (int i = 0; i < nodo.cantidadClaves; i++) {

            // Primero se visita el hijo izquierdo.
            if (!nodo.esHoja) {
                recorrerEnOrdenRecursivo(nodo.hijos[i], resultado);
            }

            // Despues se agrega la clave actual.
            resultado.add(nodo.claves[i]);
        }

        // Finalmente se visita el ultimo hijo.
        if (!nodo.esHoja) {
            recorrerEnOrdenRecursivo( nodo.hijos[nodo.cantidadClaves], resultado
            );
        }
    }

    // ------7. BUSQUEDA POR RANGO-------

    // Obtiene las claves comprendidas entre dos valores.
    public List<Integer> buscarRango(int minimo, int maximo) {
        List<Integer> resultado = new ArrayList<>();

        if (minimo > maximo) {
            return resultado;
        }

        for (int clave : recorrerEnOrden()) {
            if (clave >= minimo && clave <= maximo) {
                resultado.add(clave);
            }
        }

        return resultado;
    }

    // -----8. ALTURA----------

    /**
     * Calcula la altura del arbol.
     *
     * Un arbol vacio tiene altura 0, un arbol con una sola raiz tiene altura 1.
     */
    public int altura() {
        if (estaVacio()) {
            return 0;
        }

        int niveles = 0;
        NodoB actual = raiz;

        while (actual != null) {
            niveles++;

            if (actual.esHoja) {
                break;
            }

            actual = actual.hijos[0];
        }
        return niveles;
    }

    // ------9. MOSTRAR ARBOL POR NIVELES-------

    //Imprime el arbol B por niveles.
    public String imprimirPorNiveles() {
        if (estaVacio()) {
            return "El arbol esta vacio.";
        }

        StringBuilder texto = new StringBuilder();

        // Calculamos la altura total del arbol.
        int alturaArbol = altura();
        // Recorremos cada nivel desde la raiz.
        for (int nivel = 0; nivel < alturaArbol; nivel++) {
            texto.append("Nivel ")
                 .append(nivel)
                 .append(": ");

            // Imprime todos los nodos del nivel actual.
            imprimirNivel(raiz, nivel, texto);
            texto.append("\n");
        }

        return texto.toString();
    }

    /** Recorre el arbol hasta encontrar los nodos que pertenecen al nivel solicitado.
     *
     * @param nodo nodo actual.
     * @param nivel nivel que se desea imprimir.
     * @param texto almacena el resultado.
     */
    private void imprimirNivel( NodoB nodo, int nivel, StringBuilder texto) {
        // Si llegamos al nivel solicitado, imprimimos todas las claves del nodo actual.
        if (nivel == 0) {
            texto.append("[");

            for (int i = 0; i < nodo.cantidadClaves; i++) {
                texto.append(nodo.claves[i]);

                if (i < nodo.cantidadClaves - 1) {
                    texto.append(" | ");
                }
            }

            texto.append("] ");

        } else {

            // Si todavía no llegamos al nivel deseado, continuamos recorriendo sus hijos.
            if (!nodo.esHoja) {
                for (int i = 0; i <= nodo.cantidadClaves; i++) {
                    imprimirNivel(nodo.hijos[i], nivel - 1, texto);
                }
            }
        }
    }
    
    // -----------10. ELIMINACION DE CLAVES------

    /**
     * Elimina una clave del arbol B.
     *
     * @param clave elemento que se desea eliminar.
     * @return true si se elimino, false si no existe.
     */
    public boolean eliminar(int clave) {
        // Primero verificamos si la clave existe.
        if (!buscar(clave)) {
            return false;
        }
        // Iniciamos la eliminacion desde la raiz.
        eliminarRecursivo(raiz, clave);

        // Si la raiz queda sin claves, debemos reorganizar la estructura del arbol.
        if (raiz.cantidadClaves == 0) {
            if (raiz.esHoja) {
                // Si era una hoja, creamos una nueva raiz vacia.
                raiz = new NodoB(D, true);

            } else {
                // Si tenia hijos, el primer hijo se convierte en la nueva raiz.
                raiz = raiz.hijos[0];
            }
        }
        return true;
    }

     // Realiza la eliminacion de manera recursiva.
    private void eliminarRecursivo(NodoB nodo, int clave) {
        int i = 0;
        // Buscamos la posicion de la clave.
        while (i < nodo.cantidadClaves && clave > nodo.claves[i]) {
            i++;
        }

        // CASO 1: La clave se encuentra en el nodo actual.
        if (i < nodo.cantidadClaves && nodo.claves[i] == clave) {
            if (nodo.esHoja) {
                // Si es una hoja, eliminamos directamente.
                eliminarDeHoja(nodo, i);
            } else {
                // Si es un nodo interno, buscamos su predecesor en el subarbol izquierdo.
                int predecesor = obtenerPredecesor(nodo.hijos[i]);
                // Reemplazamos la clave por su predecesor.
                nodo.claves[i] = predecesor;
                // Eliminamos el predecesor de su ubicacion original.
                eliminarRecursivo(nodo.hijos[i], predecesor);
                // Verificamos si el hijo quedo con menos de D claves.
                repararHijo(nodo, i);
            }
        } else {
            // CASO 2: La clave no esta en este nodo continuamos la busqueda por el hijo correspondiente.
            if (!nodo.esHoja) {
                eliminarRecursivo(nodo.hijos[i], clave);

                // Despues de eliminar, revisamos si el hijo necesita redistribucion o fusion.
                repararHijo(nodo, i);
            }
        }
    }

    /**
     * Elimina una clave de una hoja desplazando las claves posteriores una posicion a la izquierda.
     *
     * @param nodo hoja donde se encuentra la clave.
     * @param posicion posicion de la clave.
     */
    private void eliminarDeHoja(NodoB nodo, int posicion) {

        for (int i = posicion; i < nodo.cantidadClaves - 1; i++) {
            nodo.claves[i] = nodo.claves[i + 1];
        }

        nodo.cantidadClaves--;
        // Limpiamos la posicion que quedo libre.
        nodo.claves[nodo.cantidadClaves] = 0;
    }

    // -----------11. OBTENER PREDECESOR----------

    /**
     * Obtiene la clave mayor del subarbol indicado.
     *
     * El predecesor es la clave inmediatamente anterior a otra clave dentro del recorrido ordenado.
     */
    private int obtenerPredecesor(NodoB nodo) {
        // Avanzamos siempre por el ultimo hijo.
        while (!nodo.esHoja) {
            nodo = nodo.hijos[nodo.cantidadClaves];
        }
        // La ultima clave de la hoja es el predecesor.
        return nodo.claves[nodo.cantidadClaves - 1];
    }

    // ----------12. REPARAR UN HIJO---------

    /**
     * Comprueba si un hijo tiene menos de D claves.
     *
     * Primero intenta redistribuir. Si no es posible, realiza una fusion.
     *
     * @param padre nodo que contiene la referencia al hijo.
     * @param posicion indice del hijo que se debe revisar.
     */
    private void repararHijo(NodoB padre, int posicion) {
        NodoB hijo = padre.hijos[posicion];
        // Si tiene D o mas claves, no necesita reparacion.
        if (hijo.cantidadClaves >= D) {
            return;
        }
        // PRIMERA OPCION: pedir una clave al hermano izquierdo.
        if (posicion > 0 && padre.hijos[posicion - 1].cantidadClaves > D) {
            redistribuirDesdeIzquierda(padre, posicion);

        // SEGUNDA OPCION: pedir una clave al hermano derecho.
        } else if (posicion < padre.cantidadClaves && padre.hijos[posicion + 1].cantidadClaves > D) {
            redistribuirDesdeDerecha(padre, posicion);

        } else {
            // TERCERA OPCION: fusionar con un hermano.
            if (posicion > 0) {
                fusionar(padre, posicion - 1);

            } else {
                fusionar(padre, posicion);
            }
        }
    }

    // -----13. REDISTRIBUCION DESDE LA IZQUIERDA---------

    /**
     * El hermano izquierdo presta una clave al hijo.
     *
     * La clave del padre baja al hijo y la mayor clave del hermano izquierdo sube al padre.
     */
    private void redistribuirDesdeIzquierda( NodoB padre, int posicion) {
        NodoB hijo = padre.hijos[posicion];
        NodoB hermano = padre.hijos[posicion - 1];
        // Desplazamos las claves del hijo a la derecha.
        for (int i = hijo.cantidadClaves; i > 0; i--) {
            hijo.claves[i] = hijo.claves[i - 1];
        }

        // Si el hijo es interno, tambien desplazamos sus referencias a los hijos.
        if (!hijo.esHoja) {
            for (int i = hijo.cantidadClaves + 1; i > 0; i--) {
                hijo.hijos[i] = hijo.hijos[i - 1];
            }
            // El ultimo hijo del hermano pasa al primero del hijo.
            hijo.hijos[0] = hermano.hijos[hermano.cantidadClaves];
            hermano.hijos[hermano.cantidadClaves] = null;
        }
        // La clave del padre baja al hijo.
        hijo.claves[0] = padre.claves[posicion - 1];
        // La mayor clave del hermano sube al padre.
        padre.claves[posicion - 1] = hermano.claves[hermano.cantidadClaves - 1];
        hermano.claves[hermano.cantidadClaves - 1] = 0;

        hijo.cantidadClaves++;
        hermano.cantidadClaves--;
    }

    // ------14. REDISTRIBUCION DESDE LA DERECHA----------

    /**
     * El hermano derecho presta una clave al hijo.
     *
     * La clave del padre baja al hijo y la menor clave del hermano derecho sube al padre.
     */
    private void redistribuirDesdeDerecha(NodoB padre, int posicion) {
        NodoB hijo = padre.hijos[posicion];
        NodoB hermano = padre.hijos[posicion + 1];

        // La clave del padre baja al final del hijo.
        hijo.claves[hijo.cantidadClaves] = padre.claves[posicion];

        // Si son nodos internos, tambien se mueve  el primer hijo del hermano derecho.
        if (!hijo.esHoja) {
            hijo.hijos[hijo.cantidadClaves + 1] = hermano.hijos[0];
        }

        // La primera clave del hermano sube al padre.
        padre.claves[posicion] = hermano.claves[0];
        // Desplazamos las claves del hermano a la izquierda.
        for (int i = 0; i < hermano.cantidadClaves - 1; i++) {
            hermano.claves[i] = hermano.claves[i + 1];
        }
        // Si es interno, tambien desplazamos sus hijos.
        if (!hermano.esHoja) {
            for (int i = 0; i < hermano.cantidadClaves; i++) {
                hermano.hijos[i] = hermano.hijos[i + 1];
            }
            hermano.hijos[hermano.cantidadClaves] = null;
        }
        hermano.claves[hermano.cantidadClaves - 1] = 0;

        hijo.cantidadClaves++;
        hermano.cantidadClaves--;
    }

    // ------------15. FUSION DE NODOS---------------

    /**
     * Fusiona dos hijos utilizando la clave que los separa en el padre.
     *
     * @param padre nodo que contiene la clave separadora.
     * @param posicion indice de la clave separadora.
     */
    private void fusionar(NodoB padre, int posicion) {
        NodoB izquierdo = padre.hijos[posicion];
        NodoB derecho = padre.hijos[posicion + 1];
        // La clave separadora del padre baja al nodo izquierdo.
        izquierdo.claves[izquierdo.cantidadClaves] = padre.claves[posicion];
        izquierdo.cantidadClaves++;

        // Copiamos las claves del nodo derecho.
        for (int i = 0; i < derecho.cantidadClaves; i++) {
            izquierdo.claves[izquierdo.cantidadClaves + i] = derecho.claves[i];
        }
        // Actualizamos la cantidad total de claves.
        izquierdo.cantidadClaves += derecho.cantidadClaves;
        // Si son nodos internos, copiamos tambien sus hijos.
        if (!izquierdo.esHoja) {
            for (int i = 0; i <= derecho.cantidadClaves; i++) {
                izquierdo.hijos[izquierdo.cantidadClaves - derecho.cantidadClaves + i ] = derecho.hijos[i];
            }
        }

        // Eliminamos del padre la clave separadora.
        for (int i = posicion; i < padre.cantidadClaves - 1; i++) {
            padre.claves[i] = padre.claves[i + 1];
        }
        // Eliminamos la referencia al nodo derecho.
        for (int i = posicion + 1; i < padre.cantidadClaves; i++) {
            padre.hijos[i] = padre.hijos[i + 1];
        }
        padre.claves[padre.cantidadClaves - 1] = 0;
        padre.hijos[padre.cantidadClaves] = null;

        padre.cantidadClaves--;
    }
}
