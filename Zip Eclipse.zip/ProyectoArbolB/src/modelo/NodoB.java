package modelo;


/**
 * Representa una página o nodo de un arbol B de orden D.
 *
 * Cada nodo puede almacenar como maximo 2D claves.
 * Tambien puede tener como maximo 2D + 1 hijos.
 */
public class NodoB {

    /* Arreglo que almacena las claves del nodo.
    Se reserva una posicion adicional para controlar temporalmente el desbordamiento durante la insercion.*/
    int[] claves;

    /* Arreglo que almacena las referencias a los hijos.
    Se reserva espacio para 2D + 2 hijos.*/
    NodoB[] hijos;

    // Cantidad de claves que tiene actualmente el nodo.
    int cantidadClaves;

    /* Indica si el nodo es una hoja.
     true: no tiene hijos  o  false: es un nodo interno.*/
    boolean esHoja;

    /**
     * Constructor del nodo.
     *
     * @param D cantidad minima de claves del arbol.
     * @param esHoja indica si el nodo es una hoja.
     */
    public NodoB(int D, boolean esHoja) {
        // Espacio para 2D + 1 claves.
        claves = new int[2 * D + 1];

        // Espacio para 2D + 2 hijos.
        hijos = new NodoB[2 * D + 2];

        cantidadClaves = 0;
        this.esHoja = esHoja;
    }

    //Devuelve la cantidad actual de claves.
    public int getCantidadClaves() {
        return cantidadClaves;
    }

    //Indica si el nodo es una hoja.
    public boolean esHoja() {
        return esHoja;
    }
}
