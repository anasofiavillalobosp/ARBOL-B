package vista;

import java.util.List;
import java.util.Scanner;

/**
 * Vista encargada de la interacción con el usuario.
 *
 * Muestra el menú del árbol B, solicita los datos y presenta los resultados en consola.
 * No contiene la lógica de las operaciones del árbol.
 */
public class VistaArbolB {
    // Permite leer los datos ingresados por el usuario en consola.
    private Scanner teclado;
    /**
     * Constructor de la vista.
     */
    public VistaArbolB() {
        teclado = new Scanner(System.in);
    }

    /**
     * Muestra las opciones disponibles del programa.
     * @return opción seleccionada por el usuario.
     */
    public int mostrarMenu() {
        System.out.println("\n========== ARBOL B ==========");
        System.out.println("1. Insertar clave");
        System.out.println("2. Buscar clave");
        System.out.println("3. Eliminar clave");
        System.out.println("4. Consultar minimo");
        System.out.println("5. Consultar maximo");
        System.out.println("6. Buscar rango");
        System.out.println("7. Recorrer En Orden");
        System.out.println("8. Mostrar arbol por niveles");
        System.out.println("9. Consultar altura");
        System.out.println("10. Consultar si esta vacio");
        System.out.println("11. Limpiar arbol");
        System.out.println("0. Salir");
        System.out.println("==============================");

        return leerEntero("Seleccione una opcion: ");
    }

    /**
     * Solicita un numero entero al usuario.
     *
     * @param mensaje texto que se mostrara al usuario.
     * @return numero entero ingresado.
     */
    public int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                return Integer.parseInt(teclado.nextLine());// Se utiliza nextLine() para evitar problemas con el salto de linea que deja Scanner.
            } catch (NumberFormatException e) {
                System.out.println("Error: debe ingresar un numero entero.");
            }
        }
    }

    /**
     * Muestra un mensaje general en consola.
     * @param mensaje texto que se desea mostrar.
     */
    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }

    /**
     * Muestra el resultado de una busqueda.
     * @param encontrada indica si la clave existe.
     * @param clave clave consultada.
     */
    public void mostrarResultadoBusqueda(boolean encontrada, int clave) {
        if (encontrada) {
            System.out.println("La clave " + clave + " existe en el arbol.");
        } else {
            System.out.println("La clave " + clave + " no existe en el arbol.");
        }
    }

    /**
     * Muestra una lista de claves.
     * @param claves lista que se desea presentar.
     */
    public void mostrarClaves(List<Integer> claves) {
        if (claves == null || claves.isEmpty()) {
            System.out.println("No hay claves para mostrar.");
        } else {
            System.out.println(claves);
        }
    }

    /**
     * Muestra el resultado del minimo o maximo.
     * @param valor clave consultada.
     * @param tipo indica si se trata del minimo o maximo.
     */
    public void mostrarExtremo(Integer valor, String tipo) {
        if (valor == null) {
            System.out.println("El arbol esta vacio. No hay " + tipo + ".");
        } else {
            System.out.println(tipo + " del arbol: " + valor);
        }
    }

    /**
     * Muestra la representacion del arbol por niveles.
     * @param arbol texto con los niveles del arbol.
     */
    public void mostrarArbol(String arbol) {
        System.out.println(arbol);
    }

    /**
     * Muestra la altura del arbol.
     * @param altura altura calculada por el modelo.
     */
    public void mostrarAltura(int altura) {
        System.out.println("Altura del arbol: " + altura);
    }
}